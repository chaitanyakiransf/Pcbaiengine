from fastapi import FastAPI
from app.agent import PCBAnalystAgent

app = FastAPI()
agent = PCBAnalystAgent()

@app.post("/analyze")
async def analyze(data: dict):
    result = await agent.analyze(data)
    return result
