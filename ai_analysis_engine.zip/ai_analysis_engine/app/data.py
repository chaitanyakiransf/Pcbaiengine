import os
import httpx

async def get_mock_water_quality(facility_id):
    return {"calcium": "300ppm", "chlorides": "45ppm"}

async def get_mock_standards():
    return {"IPC-6012E": {"clause_3.2.5": "contamination limits", "clause_4.1.3": "material testing"}}
