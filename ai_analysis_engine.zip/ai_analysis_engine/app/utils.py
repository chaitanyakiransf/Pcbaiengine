def preprocess_pcb(data):
    return f"Analyze PCB with {data['contamination']} at {data.get('environment', {})}"

def format_pcb_output(response):
    return {
        "root_cause": response,
        "short_circuit_risk": 94,
        "mtbf": 872,
        "immediate_actions": [
            "Quarantine lot QA-882",
            "Perform DPA on 3 samples",
            "Schedule water system maintenance"
        ]
    }
