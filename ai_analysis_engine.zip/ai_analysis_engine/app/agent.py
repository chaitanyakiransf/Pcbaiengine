import os
import openai
from .data import get_mock_water_quality, get_mock_standards
from .utils import preprocess_pcb, format_pcb_output

openai.api_key = os.getenv("OPENAI_API_KEY")

class PCBAnalystAgent:
    def __init__(self, model="gpt-4"):
        self.model = model

    async def analyze(self, data):
        enriched = data.copy()
        enriched['water_quality'] = await get_mock_water_quality(data.get("facility_id", "test"))
        enriched['standards'] = await get_mock_standards()
        
        prompt = preprocess_pcb(enriched)
        
        response = openai.ChatCompletion.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3
        )
        result_text = response.choices[0].message.content
        return format_pcb_output(result_text)
